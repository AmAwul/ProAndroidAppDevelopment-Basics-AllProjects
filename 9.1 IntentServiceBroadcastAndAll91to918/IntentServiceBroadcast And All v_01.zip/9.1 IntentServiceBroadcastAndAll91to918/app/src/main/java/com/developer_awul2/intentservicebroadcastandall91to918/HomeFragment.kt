package com.developer_awul2.intentservicebroadcastandall91to918

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation.findNavController
import com.developer_awul2.intentservicebroadcastandall91to918.R
import com.developer_awul2.intentservicebroadcastandall91to918.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private var navController: NavController? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root


        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnIntent.setOnClickListener {
            navController?.navigate(R.id.action_nav_home_to_intentFragment)
        }

        binding.btnService.setOnClickListener {
            navController?.navigate(R.id.action_nav_home_to_serviceFragment)
        }



        navController = findNavController(view)



//        navController.navigate(R.id.action_nav_home_to_nav_wholesales)

    }



    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}